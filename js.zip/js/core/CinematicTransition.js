/**
 * CinematicTransition.js — TAV Cinematic Scene Transition Controller v2
 * ====================================================================
 * SINGLE SOURCE OF TRUTH for ALL scene transition animations.
 * Shared by: Desktop Layout 1–11 · Mobile Layout 1–10
 *
 * v2 — FOV-BASED PULL-BACK (replaces CSS scale approach)
 * -------------------------------------------------------
 * WHY v2:
 *   CSS transform: scale() on #container shrinks the rendered DOM node,
 *   exposing the black page background as borders. This is a webpage
 *   shrinking — not a camera moving.
 *
 * HOW v2 WORKS:
 *   Animate pano.setFov() via requestAnimationFrame.
 *   Increasing FOV = camera retreats, panorama widens to fill viewport.
 *   The panorama renderer ALWAYS fills 100% of screen.
 *   No black borders. No CSS artifacts. Pure camera movement.
 *   No blur. No overlay. No DOM scaling.
 *
 * Cinematic Sequence:
 *   ────────────────────────────────────────────────────────────────
 *   [Phase 1]  Pull Back     750ms   FOV 100°→118°  easeOutExpo
 *              Camera retreats. Panorama widens. Viewport always full.
 *   ────────────────────────────────────────────────────────────────
 *   [Phase 2a] Hold (exit)   450ms   Stay at 118°
 *              User perceives the pull-back. Cinematic pause.
 *   ────────────────────────────────────────────────────────────────
 *   [Phase 2b] Scene Switch          pano.openNext({fov:118°})
 *              Destination loads immediately at same pulled-back FOV.
 *              No zoom-in. No FOV reset flash.
 *   ────────────────────────────────────────────────────────────────
 *   [Phase 2c] Hold (arrive) 380ms   Destination at 118°
 *              User perceives the new environment before settling.
 *   ────────────────────────────────────────────────────────────────
 *   [Phase 3]  Settle        620ms   FOV 118°→100°  easeOutQuint
 *              Camera drifts to rest. No snap. No acceleration.
 *   ────────────────────────────────────────────────────────────────
 *   Total: ~2.2s. Calm, luxurious, physically believable.
 *
 * Intercepts (via monkey-patch on window.pano.openNext):
 *   ✓ Hotspots            ✓ Navigation menu      ✓ Mini map
 *   ✓ Scene cards         ✓ Premium Carousel     ✓ Gallery cards
 *   ✓ Mobile layouts 1–10 ✓ Desktop layouts 1–11 ✓ Hash URL
 *
 * NOT present (v2 removes these):
 *   ✗ CSS transform: scale() on container
 *   ✗ CSS filter: blur()
 *   ✗ Dark/light overlays
 *   ✗ willChange: transform hints on container
 *   ✗ Any effect that exposes page background
 * ====================================================================
 */

(function () {
  'use strict';

  // ─────────────────────────────────────────────────────────────────
  // CONFIGURATION
  // ─────────────────────────────────────────────────────────────────
  var CONFIG = {
    // FOV pull-back
    // Normal FOV is 100° (from pano.xml <start fov="100">).
    // Adding 32° → FOV peaks at 132°: clearly cinematic, objects appear smaller.
    // Max safe FOV is 138° (scene max in XML is 140°; 2° safety margin).
    normalFov:         106,   // degrees — settle FOV (slightly wider than default = smaller view)
    pullAmount:        38,    // degrees — retreat amount (106+38 peaks at 138°, capped at maxFov)
    maxFov:            138,   // degrees — hard cap

    // Phase 1: Pull-back animation
    pullDuration:      850,   // ms — slow, deliberate retreat
    // easeInOutCubic: starts gently → accelerates → decelerates gracefully
    // No sudden jerk at the beginning. Feels like a real camera dolly.
    pullEase:          'easeInOutCubic',

    // Phase 2a: Hold before scene switch
    switchDelay:       350,   // ms — brief pause, not too long to feel stuck

    // Phase 2c: Hold after destination appears
    postSwitchHold:    480,   // ms — hold longer so user reads new scene

    // Phase 3: Gentle FOV return
    settleDuration:    1100,  // ms — very slow, lazy camera drift back
    // easeInOutSine: ultra-smooth S-curve — no snap, continuously decelerating
    settleEase:        'easeInOutSine',

    // Safety
    lockTimeout:       2600,  // ms — full sequence + buffer
    pollInterval:      80,    // ms — pano readiness poll
    pollMaxAttempts:   150,   // 12s max wait for pano engine

    debug:             false, // set true for console timing logs
  };

  // ─────────────────────────────────────────────────────────────────
  // STATE
  // ─────────────────────────────────────────────────────────────────
  var _isTransitioning   = false;
  var _lockTimer         = null;
  var _rafHandle         = null;
  var _patchInstalled    = false;
  var _originalOpenNext  = null;
  var _INTERNAL_CALL     = false;

  // ─────────────────────────────────────────────────────────────────
  // EASING FUNCTIONS
  // Pure JS — used with RAF for frame-accurate FOV control
  // ─────────────────────────────────────────────────────────────────
  var EASINGS = {
    // easeInOutCubic: gentle start → accelerates → gentle end
    // Like a camera dolly: eases in from rest, moves, eases back to rest.
    // No jerk. No sudden snap. Physically convincing.
    easeInOutCubic: function (t) {
      return t < 0.5
        ? 4 * t * t * t
        : 1 - Math.pow(-2 * t + 2, 3) / 2;
    },

    // easeInOutSine: the smoothest possible S-curve (sine wave)
    // Ultra-gentle — camera drifts to rest like floating in water.
    easeInOutSine: function (t) {
      return -(Math.cos(Math.PI * t) - 1) / 2;
    },

    // easeOutExpo: fast start, long graceful tail (kept for compatibility)
    easeOutExpo: function (t) {
      return t >= 1 ? 1 : 1 - Math.pow(2, -10 * t);
    },

    // easeOutQuint: smooth deceleration (kept for compatibility)
    easeOutQuint: function (t) {
      return 1 - Math.pow(1 - t, 5);
    },
  };

  // ─────────────────────────────────────────────────────────────────
  // UTILITIES
  // ─────────────────────────────────────────────────────────────────
  function log() {
    if (!CONFIG.debug) return;
    var args = Array.prototype.slice.call(arguments);
    args.unshift('[CinematicTransition v2]');
    console.log.apply(console, args);
  }

  function getPano() {
    return window.pano || null;
  }

  function getCurrentFov() {
    var pano = getPano();
    if (!pano || typeof pano.getFov !== 'function') return CONFIG.normalFov;
    var fov = pano.getFov();
    return (fov && !isNaN(fov) && fov > 0) ? fov : CONFIG.normalFov;
  }

  // ─────────────────────────────────────────────────────────────────
  // CLEAN UP LEGACY CSS (v1 left transform/filter/willChange on container)
  // ─────────────────────────────────────────────────────────────────
  function cleanupLegacyStyles() {
    var el = document.getElementById('container');
    if (!el) return;
    el.style.willChange           = '';
    el.style.transformOrigin      = '';
    el.style.backfaceVisibility   = '';
    el.style.webkitBackfaceVisibility = '';
    el.style.transform            = '';
    el.style.webkitTransform      = '';
    el.style.filter               = '';
    el.style.webkitFilter         = '';
    el.style.transition           = '';
    el.style.webkitTransition     = '';
  }

  // ─────────────────────────────────────────────────────────────────
  // LOCK MANAGEMENT
  // ─────────────────────────────────────────────────────────────────
  function acquireLock() {
    _isTransitioning = true;
    clearTimeout(_lockTimer);
    _lockTimer = setTimeout(function () {
      if (_isTransitioning) {
        log('⚠ Lock timeout — force release');
        releaseLock();
      }
    }, CONFIG.lockTimeout);
  }

  function releaseLock() {
    _isTransitioning = false;
    clearTimeout(_lockTimer);
    _lockTimer = null;
    if (_rafHandle) {
      cancelAnimationFrame(_rafHandle);
      _rafHandle = null;
    }
    log('Lock released');
  }

  // ─────────────────────────────────────────────────────────────────
  // FOV ANIMATION ENGINE
  // Uses requestAnimationFrame for frame-perfect, GPU-synced animation.
  // pano.setFov() updates the panorama renderer each frame.
  // The panorama ALWAYS fills 100% of viewport — no borders possible.
  // ─────────────────────────────────────────────────────────────────
  function animateFov(fromFov, toFov, durationMs, easeName, onComplete) {
    var pano = getPano();
    if (!pano || typeof pano.setFov !== 'function') {
      // FOV API not available — skip animation, call completion directly
      log('⚠ setFov not available — skipping FOV animation');
      if (onComplete) onComplete();
      return;
    }

    // Cancel any running FOV animation
    if (_rafHandle) {
      cancelAnimationFrame(_rafHandle);
      _rafHandle = null;
    }

    var easeFn = EASINGS[easeName] || EASINGS.easeOutQuint;
    var startTime = null;

    function frame(timestamp) {
      if (!startTime) startTime = timestamp;

      var elapsed  = timestamp - startTime;
      var progress = Math.min(elapsed / durationMs, 1);
      var eased    = easeFn(progress);
      var fov      = fromFov + (toFov - fromFov) * eased;

      // Set FOV — panorama renderer updates immediately, fills full viewport
      try { pano.setFov(fov); } catch (e) { /* ignore single-frame errors */ }

      if (progress < 1) {
        _rafHandle = requestAnimationFrame(frame);
      } else {
        _rafHandle = null;
        // Snap to exact target at completion — no floating point drift
        try { pano.setFov(toFov); } catch (e) {}
        if (onComplete) onComplete();
      }
    }

    _rafHandle = requestAnimationFrame(frame);
  }

  // ─────────────────────────────────────────────────────────────────
  // MASTER TRANSITION EXECUTOR
  // ─────────────────────────────────────────────────────────────────
  function executeCinematicTransition(nodeStr) {
    // Debounce: ignore rapid-fire triggers
    if (_isTransitioning) {
      log('⚠ Already transitioning — ignoring:', nodeStr);
      return;
    }

    var pano = getPano();
    if (!pano || !_originalOpenNext) {
      // Engine not ready — pass through directly
      if (pano && pano.openNext) pano.openNext(nodeStr);
      return;
    }

    // Capture current FOV at the moment of trigger
    var startFov = getCurrentFov();
    var pullFov  = Math.min(startFov + CONFIG.pullAmount, CONFIG.maxFov);

    log('▶ Transition:', nodeStr, '| FOV:', startFov, '→', pullFov, '→', CONFIG.normalFov);

    acquireLock();

    // ── Phase 1: Pull Back ──────────────────────────────────────────
    // Animate FOV from current to pulled-back.
    // Increasing FOV = wider angle = camera retreats.
    // Panorama always fills viewport — no black borders possible.
    log('Phase 1 — pull back FOV', startFov, '→', pullFov);

    animateFov(startFov, pullFov, CONFIG.pullDuration, CONFIG.pullEase, function () {

      // ── Phase 2a: Hold ────────────────────────────────────────────
      // Camera is pulled back. User perceives the retreat.
      log('Phase 2a — holding', CONFIG.switchDelay, 'ms');

      setTimeout(function () {

        // ── Phase 2b: Scene Switch ────────────────────────────────────
        // Load destination panorama at the same pulled-back FOV.
        // Pass { fov: pullFov } as startView so destination loads already
        // at the retreated FOV — no flash, no zoom-in, seamless.
        log('Phase 2b — scene switch (fov=' + pullFov + ')');

        var stabilized = false;

        function doSettle() {
          if (stabilized) return;
          stabilized = true;

          // Force FOV to pullFov in case pano2vr reset it on load.
          // This ensures destination is perceived at the retreated scale.
          try { pano.setFov(pullFov); } catch (e) {}

          // ── Phase 2c: Hold ──────────────────────────────────────────
          // Destination scene visible at retreated FOV.
          // User perceives new environment before camera settles.
          log('Phase 2c — holding at arrival', CONFIG.postSwitchHold, 'ms');

          setTimeout(function () {

            // ── Phase 3: Settle ─────────────────────────────────────────
            // Camera gently drifts back to normal FOV.
            // easeOutQuint: smooth deceleration, no snap, no jarring stop.
            log('Phase 3 — settling FOV', pullFov, '→', CONFIG.normalFov);

            animateFov(pullFov, CONFIG.normalFov, CONFIG.settleDuration, CONFIG.settleEase, function () {
              log('✓ Transition complete');
              releaseLock();
            });

          }, CONFIG.postSwitchHold);
        }

        // Primary: Pano2VR event-driven settle trigger
        // 'changenode' fires the moment pano renders the new scene
        var listenerInstalled = false;
        if (typeof pano.addListener === 'function') {
          try {
            pano.addListener('changenode', function onChanged() {
              // Remove listener immediately (one-shot)
              try { pano.removeEventListener('changenode', onChanged); } catch (e) {}
              doSettle();
            });
            listenerInstalled = true;
          } catch (e) { /* addListener not available */ }
        }

        // Fallback: timer fires if changenode doesn't
        // (handles edge cases where event system is unavailable)
        setTimeout(doSettle, 550);

        // Execute the actual scene switch
        _INTERNAL_CALL = true;
        try {
          // Pass startView with our pulled-back FOV.
          // pano2vr will load the destination at this FOV directly.
          _originalOpenNext(nodeStr, { fov: pullFov });
        } catch (err) {
          // Fallback: call without startView parameter
          try { _originalOpenNext(nodeStr); } catch (e2) {}
          console.warn('[CinematicTransition] openNext error:', err);
          releaseLock();
        } finally {
          _INTERNAL_CALL = false;
        }

      }, CONFIG.switchDelay);
    });
  }

  // ─────────────────────────────────────────────────────────────────
  // MONKEY-PATCH — Intercepts ALL window.pano.openNext() calls
  //
  // Single intercept point covering every navigation trigger:
  //   shared_core.js navigateTo() → openNext
  //   modern_ui.js (18 call sites) → openNext
  //   mobile_ui.js (3 call sites) → openNext
  //   js/mobile/mobile_layout*.js (15 call sites via TAV_CORE.navigateTo)
  //   js/components/PremiumCarousel.js → openNext
  //   js/components/UITemplates.js → openNext
  //   index.html hash navigation → openNext
  // ─────────────────────────────────────────────────────────────────
  function installPatch() {
    if (_patchInstalled) return;

    var pano = window.pano;
    if (!pano || typeof pano.openNext !== 'function') return;

    _originalOpenNext = pano.openNext.bind(pano);

    pano.openNext = function (nodeStr, startView) {
      // Pass through: our own internal calls during the transition
      if (_INTERNAL_CALL) {
        return _originalOpenNext(nodeStr, startView);
      }

      // Parse node ID
      var nodeId = (nodeStr || '').replace(/[{}\s]/g, '');

      // Pass through: non-panorama destinations
      // Gallery nodes (nodegallarey*) and architecture overlays skip transition
      if (!nodeId ||
          nodeId.indexOf('nodegallarey') === 0 ||
          nodeId.indexOf('architecture-') === 0) {
        log('Pass-through (non-node):', nodeStr);
        return _originalOpenNext(nodeStr, startView);
      }

      // Execute cinematic FOV-based transition for all real scene nodes
      executeCinematicTransition(nodeStr);
    };

    // Also attempt to disable pano's native zoom via JS API (backup to pano.xml)
    if (typeof pano.setTransition === 'function') {
      try { pano.setTransition({ zoomin: false, zoomout: false }); } catch (e) {}
    }

    // Clean up any CSS artifacts left by a previous v1 install
    cleanupLegacyStyles();

    _patchInstalled = true;
    console.log('[CinematicTransition] v2 ✓ FOV-based pull-back active — no black borders, no DOM scaling.');
  }

  // ─────────────────────────────────────────────────────────────────
  // INITIALIZATION
  // Pano2VR loads asynchronously. Poll until engine is ready.
  // ─────────────────────────────────────────────────────────────────
  function init() {
    // Immediate attempt (handles synchronous initialization edge case)
    if (window.pano && typeof window.pano.openNext === 'function') {
      installPatch();
      return;
    }

    var attempts = 0;
    var pollTimer = setInterval(function () {
      attempts++;
      if (window.pano && typeof window.pano.openNext === 'function') {
        clearInterval(pollTimer);
        installPatch();
        return;
      }
      if (attempts >= CONFIG.pollMaxAttempts) {
        clearInterval(pollTimer);
        console.warn('[CinematicTransition] ✗ Pano engine not found after 12s.');
      }
    }, CONFIG.pollInterval);

    // Accelerate install via configloaded event when pano registers early
    var hookAttempts = 0;
    var hookTimer = setInterval(function () {
      hookAttempts++;
      if (hookAttempts > 60) { clearInterval(hookTimer); return; }
      if (window.pano && typeof window.pano.addListener === 'function') {
        clearInterval(hookTimer);
        try {
          window.pano.addListener('configloaded', function () {
            clearInterval(pollTimer);
            installPatch();
          });
        } catch (e) { /* ignore */ }
      }
    }, 80);
  }

  // ─────────────────────────────────────────────────────────────────
  // PUBLIC API — For debugging and live tuning in DevTools
  // ─────────────────────────────────────────────────────────────────
  window.TAV_TRANSITION = {
    /** @returns {boolean} True if a transition is currently running */
    isTransitioning: function () { return _isTransitioning; },

    /** Live-editable config — changes apply to next transition */
    config: CONFIG,

    /** Emergency release (if a transition gets stuck) */
    forceRelease: releaseLock,

    /** Re-install patch (after dynamic pano re-initialization) */
    reinstall: function () {
      _patchInstalled   = false;
      _originalOpenNext = null;
      installPatch();
    },

    /** Enable step-by-step console logging */
    enableDebug:  function () { CONFIG.debug = true; },
    disableDebug: function () { CONFIG.debug = false; },

    /** Live tuning examples (run in DevTools console):
     *  TAV_TRANSITION.config.pullAmount = 22;       // more dramatic retreat
     *  TAV_TRANSITION.config.pullDuration = 900;    // slower pull-back
     *  TAV_TRANSITION.config.switchDelay = 600;     // longer hold
     *  TAV_TRANSITION.config.settleDuration = 800;  // slower settling
     */
  };

  // ─────────────────────────────────────────────────────────────────
  // BOOT
  // ─────────────────────────────────────────────────────────────────
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
